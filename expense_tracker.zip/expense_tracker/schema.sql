-- Run this once in your PostgreSQL database (psql or pgAdmin)
-- e.g.:  psql -U postgres -d expense_tracker -f schema.sql

CREATE TABLE IF NOT EXISTS expenses (
  id SERIAL PRIMARY KEY,
  description TEXT NOT NULL,
  amount NUMERIC(10, 2) NOT NULL,
  category VARCHAR(20) NOT NULL CHECK (category IN ('food', 'travel', 'shopping')),
  expense_date DATE NOT NULL DEFAULT CURRENT_DATE
);

-- A couple of sample rows so the chart has something to show immediately
INSERT INTO expenses (description, amount, category, expense_date) VALUES
  ('Lunch', 150.00, 'food', CURRENT_DATE),
  ('Auto fare', 60.00, 'travel', CURRENT_DATE),
  ('Notebook', 90.00, 'shopping', CURRENT_DATE);
