# app.py
# Backend: Python (Flask) + PostgreSQL

from flask import Flask, request, jsonify, render_template
import psycopg2
import psycopg2.extras

app = Flask(__name__)

# ---- 1. Database connection ----
# Change these to match YOUR PostgreSQL setup.
DB_CONFIG = {
    "host": "localhost",
    "database": "expense_tracker",
    "user": "postgres",
    "password": "YOUR_PASSWORD_HERE",
    "port": 5432,
}

def get_connection():
    return psycopg2.connect(**DB_CONFIG)


# ---- 2. Routes ----

# Serve the frontend page
@app.route("/")
def home():
    return render_template("index.html")


# Get all expenses
@app.route("/api/expenses", methods=["GET"])
def get_expenses():
    conn = get_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM expenses ORDER BY expense_date DESC, id DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


# Add a new expense
@app.route("/api/expenses", methods=["POST"])
def add_expense():
    data = request.get_json()
    description = data.get("description")
    amount = data.get("amount")
    category = data.get("category")
    expense_date = data.get("expense_date") or None

    if not description or not amount or not category:
        return jsonify({"error": "Missing required fields"}), 400

    conn = get_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        INSERT INTO expenses (description, amount, category, expense_date)
        VALUES (%s, %s, %s, COALESCE(%s, CURRENT_DATE))
        RETURNING *
        """,
        (description, amount, category, expense_date),
    )
    new_row = cur.fetchone()
    conn.commit()
    cur.close()
    conn.close()
    return jsonify(new_row), 201


# Delete an expense
@app.route("/api/expenses/<int:expense_id>", methods=["DELETE"])
def delete_expense(expense_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM expenses WHERE id = %s", (expense_id,))
    conn.commit()
    cur.close()
    conn.close()
    return "", 204


# Totals grouped by category (this feeds the chart)
@app.route("/api/totals", methods=["GET"])
def get_totals():
    conn = get_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT category, SUM(amount) AS total FROM expenses GROUP BY category")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)


# ---- 3. Start server ----
if __name__ == "__main__":
    app.run(debug=True, port=3000)-*