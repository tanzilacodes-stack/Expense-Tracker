# Expense Tracker (Python + Flask + PostgreSQL) — Setup Steps

## 1. Create the database
Open pgAdmin or psql and run:
```
CREATE DATABASE expense_tracker;
```
Then load the schema:
```
psql -U postgres -d expense_tracker -f schema.sql
```

## 2. Set up a virtual environment (recommended)
```
python -m venv venv
venv\Scripts\activate      (Windows)
source venv/bin/activate   (Mac/Linux)
```

## 3. Install dependencies
```
pip install -r requirements.txt
```

## 4. Configure the backend
In `app.py`, update the `DB_CONFIG` dictionary (user, password) to match your
PostgreSQL install.

## 5. Run the app
```
python app.py
```

## 6. Open the app
Go to: http://localhost:3000

## How it fits together
- `schema.sql` → creates the `expenses` table in Postgres
- `app.py` → Flask API (GET/POST/DELETE expenses, GET totals) + serves the frontend
- `templates/index.html` → the page you see (Flask template)
- `static/style.css` → styling
- `static/script.js` → calls the API and draws the pie chart with Chart.js

## If you get stuck
- "psycopg2.OperationalError" → PostgreSQL isn't running, or wrong host/password in DB_CONFIG
- "ModuleNotFoundError: No module named 'flask'" → activate your venv and re-run `pip install -r requirements.txt`
- Chart not showing → open browser console (F12) and check for errors first
- Port already in use → change `port=3000` in `app.py` to another number
