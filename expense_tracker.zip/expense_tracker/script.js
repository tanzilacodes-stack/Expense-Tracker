// script.js — talks to our own Flask backend API, updates the list and the chart

const form = document.getElementById('expense-form');
const list = document.getElementById('expense-list');
let chart; // will hold the Chart.js instance so we can destroy/redraw it

// ---- Load everything on page start ----
document.addEventListener('DOMContentLoaded', () => {
  loadExpenses();
  loadTotals();
});

// ---- Add a new expense ----
form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const description = document.getElementById('description').value;
  const amount = document.getElementById('amount').value;
  const category = document.getElementById('category').value;
  const expense_date = document.getElementById('expense_date').value || null;

  await fetch('/api/expenses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ description, amount, category, expense_date }),
  });

  form.reset();
  await loadExpenses();
  loadTotals();

  // small settle-in animation on the newest entry
  const first = list.querySelector('li');
  if (first) first.classList.add('new-entry');
});

// ---- Fetch and render the expense list ----
async function loadExpenses() {
  const res = await fetch('/api/expenses');
  const expenses = await res.json();

  list.innerHTML = '';
  expenses.forEach((exp) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <span class="tag ${exp.category}" title="${exp.category}"></span>
      <span class="desc">${exp.description}</span>
      <span class="amount">₹${Number(exp.amount).toFixed(2)}</span>
      <button class="delete-btn" onclick="deleteExpense(${exp.id})">✕</button>
    `;
    list.appendChild(li);
  });
}

// ---- Delete an expense ----
async function deleteExpense(id) {
  await fetch(`/api/expenses/${id}`, { method: 'DELETE' });
  loadExpenses();
  loadTotals();
}

// ---- Fetch totals and draw/update the chart ----
async function loadTotals() {
  const res = await fetch('/api/totals');
  const totals = await res.json();

  const labels = totals.map((t) => t.category);
  const data = totals.map((t) => Number(t.total));

  const ctx = document.getElementById('totalsChart').getContext('2d');

  if (chart) chart.destroy(); // redraw fresh each time

  chart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: ['#f59e0b', '#3b82f6', '#ec4899'],
      }],
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' } },
    },
  });
}
